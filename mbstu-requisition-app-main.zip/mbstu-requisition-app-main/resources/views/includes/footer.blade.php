<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script></script> © {{ config('app.name') }}.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design &amp; Develop by Snigdho
                </div>
            </div>
        </div>
    </div>
</footer>